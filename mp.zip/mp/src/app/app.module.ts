import { BrowserModule,HAMMER_GESTURE_CONFIG  } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { HttpClientModule } from "@angular/common/http";

import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { HeaderComponent } from "./header/header.component";
import { FooterComponent } from "./footer/footer.component";
import { HomeComponent } from "./home/home.component";
/* import { AlertComponent } from "./shared/alert/alert.component"; */
import { LoadingSpinnerComponent } from "./shared/loading-spinner/loading-spinner.component";
import { PlaceholderDirective } from "./shared/placeholder/placeholder.directive";
import { NgxSpinnerModule } from "ngx-spinner";
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { GestureConfig } from '@angular/material';
 

import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
/* import { MobileSummaryComponent } from './shared/mobile-summary/mobile-summary.component'; */

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    /* AlertComponent, */
    LoadingSpinnerComponent,
    PlaceholderDirective,
    /* MobileSummaryComponent */
  ],
  imports: [BrowserModule, AppRoutingModule, HttpClientModule, NgbModule , NgxSpinnerModule,BrowserAnimationsModule],
  providers: [ { provide: HAMMER_GESTURE_CONFIG, useClass: GestureConfig }],
  bootstrap: [AppComponent]
})
export class AppModule {}
