import { Component, OnDestroy, Input, Output, EventEmitter, AfterViewInit } from "@angular/core";
import { CalculatorService } from '../calculator.service';
import { Subscription } from 'rxjs';
import { staticData } from 'src/app/shared/constant';
@Component({
  selector: "app-time",
  templateUrl: "time.component.html",
  styleUrls: ["time.component.scss"]
})
export class TimeComponent implements OnDestroy, AfterViewInit {
  @Output() passEncounterValue = new EventEmitter<any>();
  value: number = 0;
  max: number = 100;
  min: number = 10;
  range: any = 0;
  @Input() dataState: any;
  getEncounterSubs: Subscription;
  encounterName: any = "Established";
  cptCodeDisplay: any;
  timeActivityData = staticData.timeActivities;
  timeSlideNewRange = staticData.timeSlideNewRange;
  timeSlideEstRange = staticData.timeSlideEstRange;
  hiddenLabels: boolean = false;
  dataInfo: boolean = false;

  constructor(private calcService: CalculatorService) {
  }

  ngOnInit() {
    this.changeEncounterType();
    this.getSlideRange();
    this.getRange();
    this.passEncounterValue.emit(this.encounterName);
  }

  ngAfterViewInit() {
    let deviceState = this.calcService.getDeviceState();
    if (deviceState) {
      if (!this.dataState) {
        let encouter = this.calcService.getMobileTimeEnc();
        (encouter) ? this.encounterName = encouter : this.encounterName;
        this.passEncounterValue.emit(this.encounterName);
      }
    }
    else if(!this.dataState){
      let encouter = this.calcService.getEncounterMob();
      (encouter) ? this.encounterName = encouter : this.encounterName;
      this.passEncounterValue.emit(this.encounterName);
    }
  }



  changeEncounterType() {
    this.getEncounterSubs = this.calcService.getEncounterTimeName().subscribe((res) => {
      this.passEncounterValue.emit(res.data);
      this.calcService.setMobileTimeEnc(res.data);
      this.encounterName = res.data;
      if (res.timeValue) {
        this.value = parseInt(res.timeValue);
        this.onSliderChange(this.value);
        this.getSlideRange();
        this.getRange();
        this.commonValue(res.data);
      }
      else {
        this.value = 0;
        this.calcService.onSetTimeData(undefined);
        localStorage.removeItem('timeData');
        this.cptCodeDisplay = undefined;
        this.getSlideRange();
        this.getRange();
        this.commonValue(res.data);
      }
    });
  }
  commonValue(res) {
    this.max = (res === 'Established') ? 100 : 119;
    this.min = (res === 'Established') ? 10 : 15;
    this.hiddenLabels = (res === 'Established') ? false : true;
  }

  getRange() {
    if (this.encounterName === "Established") {
      this.range = ((this.value === 0) ? 0 : (this.value >= 0 && this.value <= 9) ? this.value : (this.value >= 10 && this.value <= 19) ? "10-19" : (this.value >= 20 && this.value <= 29) ? "20-29" :
        (this.value >= 30 && this.value <= 39) ? "30-39" : (this.value >= 40 && this.value <= 54) ? "40-54" : (this.value >= 55 && this.value <= 69) ? "55-69" :
          (this.value >= 70 && this.value <= 84) ? "70-84" : (this.value >= 85) ? "85+" : 0);
      this.dataInfo = ((this.value >= 85) ? true : false);
    }
    else {
      this.range = ((this.value === 0) ? 0 : (this.value >= 0 && this.value <= 14) ? this.value : (this.value >= 15 && this.value <= 29) ? "15-29" : (this.value >= 30 && this.value <= 44) ? "30-44" :
        (this.value >= 45 && this.value <= 59) ? "45-59" : (this.value >= 60 && this.value <= 74) ? "60-74" : (this.value >= 75 && this.value <= 89) ? "75-89" :
          (this.value >= 90 && this.value <= 104) ? "90-104" : (this.value >= 105) ? "105+" : 0);
      this.dataInfo = ((this.value >= 105) ? true : false);
    }
  }

  getSlideRange() {
    setTimeout(() => {
      var x = document.querySelector(".mat-slider-track-wrapper") as HTMLElement;
      var sliderliEstwidth = (x.clientWidth);
      var sliderliNewwidth = (x.clientWidth);
      this.timeSlideNewRange.forEach((element, i) => {
        document.getElementById((element.id).toString()).style.width = (sliderliNewwidth * staticData.newSliderLength[i]).toString() + "px";
      });
      this.timeSlideEstRange.forEach((res, i) => {
        document.getElementById((res.id).toString()).style.width = (sliderliEstwidth * staticData.estSliderLength[i]).toString() + "px";
      })
    });
  }

  ngOnDestroy() {
    this.getEncounterSubs.unsubscribe();
  }
  onSliderChange(val) {
    if (val) {
      this.value = val;
      (this.value > this.max) ? this.value = this.max : this.value;
      (val && val > 0) ? this.getCptCode(val) : undefined;
    }
    else {
      this.value = 0;
    }
    this.getRange();
  }

  getCptCode(val) {
    this.calcService.onSetTimeData(val);
    let data = {
      "patientType": this.encounterName,
      "time": val
    }
    this.calcService.getTimeCptCode(data).subscribe((res) => {
      (res) ? (this.cptCodeDisplay = res.cptCode) : (this.cptCodeDisplay = undefined);
    })
  }

  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

}
