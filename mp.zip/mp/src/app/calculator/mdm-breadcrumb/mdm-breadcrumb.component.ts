import { Component, OnInit, Input, Output, EventEmitter } from "@angular/core";
import { CalculatorService } from '../calculator.service';

@Component({
  selector: "app-mdm-breadcrumb",
  templateUrl: "./mdm-breadcrumb.component.html",
  styleUrls: ["./mdm-breadcrumb.component.css"]
})
export class MdmBreadcrumbComponent implements OnInit {
  @Input() public breadCrumbData: any;

  @Output() onClickReset = new EventEmitter<boolean>();

  constructor(private calcService: CalculatorService) {}

  ngOnInit() {}

  resetMdmData() {
    this.calcService.sendAlert();
    this.onClickReset.emit(true);
  }
}
