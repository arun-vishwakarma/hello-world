import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { CalculatorComponent } from "./calculator.component";
import { MobileSummaryComponent } from '../shared/mobile-summary/mobile-summary.component';

const routes: Routes = [
  {
    path: "",
    component: CalculatorComponent
  },
  {
    path:"mobile-summary",
    component:MobileSummaryComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CalculatorRoutingModule {}
