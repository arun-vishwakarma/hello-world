import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { map } from "rxjs/operators";
import { Subject, Observable } from "rxjs";
import { environment } from "src/environments/environment";

@Injectable({ providedIn: "root" })
export class CalculatorService {
  constructor(private http: HttpClient) { }
  currentMdmData: any;
  initialMdmDataState: any;
  //encounterName = new Subject<string>();
  encounterMdmName = new Subject<string>();
  encounterTimeName = new Subject<any>();
  resetAlert = new Subject<boolean>();
  summaryObj: any;
  setCondition: boolean;
  mobileDataState: any = false;
  getLevelOption: any;
  setTimeData: any;
  deviceState: any;
  setTimeEncounterMobile:any

  setEncounterForMobile: any;

  //apiUrl: string = environment.apiBaseUrl + ":" + environment.port;  
  apiUrl: string = environment.baseApiUrl;

  getCalculatorData() {
    //return 111;
    /* return this.http.get<any>("http://10.131.129.61:8080/getCptCodes").pipe(
      map(data => {
        return data;
      })
    ); */
    return this.http.get<any>(this.apiUrl + "/getQuestion");
  }

  getMdmCptCode(data) {
    return this.http.post<any>(this.apiUrl + "/getMdmCptCode", data);
  }

  getTimeCptCode(data) {
    return this.http.post<any>(this.apiUrl + "/getTimeCptCode", data);
  }

  setCurrentMdmData(data: any) {
    this.currentMdmData = data;
  }

  getCurrentMdmData() {
    return this.currentMdmData;
  }

  setInitialMdmState(data: any) {
    this.initialMdmDataState = data;
  }

  getInitialMdmState() {
    return this.initialMdmDataState;
  }

  sendEncounterName(data: any, timeValue: any) {
    this.encounterMdmName.next(data);
    this.encounterTimeName.next({ "data": data, "timeValue": timeValue });
  }
  getEncounterMdmName(): Observable<any> {
    return this.encounterMdmName.asObservable();
  }

  getEncounterTimeName(): Observable<any> {
    return this.encounterTimeName.asObservable();
  }

  sendAlert() {
    this.resetAlert.next(true);
  }
  getAlert() {
    return this.resetAlert.asObservable();
  }

  setSummaryData(data: any) {
    this.summaryObj = data;
  }

  getSummaryData() {
    return this.summaryObj;
  }

  setMobileState(data, state) {
    this.mobileDataState = data;
    this.deviceState = state;
  }
  getMobileDataState() {
    return this.mobileDataState;
  }
  getDeviceState() {
    return this.deviceState;
  }
  setOptionData(data) {
    this.getLevelOption = data;
  }
  getOptionData() {
    return this.getLevelOption;
  }
  onSetTimeData(data) {
    this.setTimeData = data;
  }
  onGetTimeData() {
    return this.setTimeData;
  }

  setEncounterMob(data) {
    this.setEncounterForMobile = data;
  }
  getEncounterMob() {
    return this.setEncounterForMobile;
  }

  setMobileTimeEnc(data){
    this.setTimeEncounterMobile=data;
  }

  getMobileTimeEnc(){
    return this.setTimeEncounterMobile;
  }


}
