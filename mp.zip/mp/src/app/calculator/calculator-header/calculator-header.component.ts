import { Component, OnInit, Output, EventEmitter, Input } from "@angular/core";
import { CalculatorService } from '../calculator.service';
import { Router } from '@angular/router';

@Component({
  selector: "app-calculator-header",
  templateUrl: "./calculator-header.component.html",
  styleUrls: ["./calculator-header.component.css"]
})
export class CalculatorHeaderComponent implements OnInit {
  constructor(private calcService: CalculatorService,private router: Router) { }
  encounterName: string = "Established";
  @Input() encounterMdmValue: any;
  @Input() encounterTimeValue: any;
  timeValue:any;

  ngOnInit() {
    this.calcService.getAlert().subscribe((res) => {
      this.encounterName="Established";
    })
    setTimeout(()=>{
    if(this.encounterMdmValue){
      this.timeValue = localStorage.getItem('timeData');
      this.changeEncounterName(this.encounterMdmValue,this.timeValue);
    }
    else {
      this.changeEncounterName(this.encounterTimeValue,undefined);
     }
    })
  }

  changeEncounterName(str: string,timeValue) {
    this.encounterName = str;
    this.calcService.sendEncounterName(this.encounterName,timeValue);
  }

  onClick(){
    localStorage.removeItem('timeData');
    this.calcService.setCurrentMdmData(undefined);
    this.router.navigate(["/"]);
  }
}
