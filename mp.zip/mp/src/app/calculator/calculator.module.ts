import { HAMMER_GESTURE_CONFIG  } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
import { CalculatorRoutingModule } from "./calculator.routing.module";
import { CalculatorComponent } from "./calculator.component";
import { CalculatorHeaderComponent } from "./calculator-header/calculator-header.component";
import { MdmBreadcrumbComponent } from "./mdm-breadcrumb/mdm-breadcrumb.component";
import { TimeComponent } from "./time/time.component";
import { MdmComponent } from "./mdm/mdm.component";
import { MatSliderModule } from '@angular/material/slider';

import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { GroupByPipe } from "../shared/group-by-pipe";
import { NgxSpinnerModule } from "ngx-spinner";
import { AlertComponent } from '../shared/alert/alert.component';
import { MobileSummaryComponent } from '../shared/mobile-summary/mobile-summary.component';
import { GestureConfig } from '@angular/material';

@NgModule({
  declarations: [
    CalculatorComponent,
    CalculatorHeaderComponent,
    MdmBreadcrumbComponent,
    TimeComponent,
    MdmComponent,
    GroupByPipe,
    AlertComponent,
    MobileSummaryComponent
  ],
  imports: [CommonModule, CalculatorRoutingModule, NgbModule, FormsModule, NgxSpinnerModule, MatSliderModule],
  providers: [ { provide: HAMMER_GESTURE_CONFIG, useClass: GestureConfig }],
  entryComponents: [AlertComponent]
})
export class CalculatorModule { }
