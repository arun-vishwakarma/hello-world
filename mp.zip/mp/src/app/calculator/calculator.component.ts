import { Component, OnInit, OnDestroy } from "@angular/core";
import { CalculatorService } from "./calculator.service";
import { NgxSpinnerService } from "ngx-spinner";
import { Subscription } from 'rxjs';

@Component({
  selector: "app-calculator",
  templateUrl: "calculator.component.html"
})
export class CalculatorComponent implements OnInit,OnDestroy {
  calcObj: any = {};
  breadCrumbData: any = {};
  currentMdmData: any;
  mdmQuestions: any;
  totalMdmQuestions: any;
  loader: boolean = false;
  dataState: any;
  encounterTimeValue: any;
  encounterMdmValue: any;
  timeValueData: any;
  resetSubscription:Subscription;

  constructor(private calcService: CalculatorService, private spinner: NgxSpinnerService) { }

  ngOnInit() {
    let deviceState=this.calcService.getDeviceState();
    (deviceState)?undefined:localStorage.removeItem('timeData');
    this.dataState = this.calcService.getMobileDataState();
    this.spinner.show();
    if (this.calcService.getOptionData()) {
      this.calcObj.activeTab = this.calcService.getOptionData();
      this.calcService.setOptionData(undefined);
    }
    else {
      this.calcObj.activeTab = "mdm";
    }
    this.setBreadCrumbData();
    this.getData();
    this.resetTimeEncounter();
  }

  ngOnDestroy(){
    this.resetSubscription.unsubscribe();
  }

  getData() {
    const currentMdmData = this.calcService.getCurrentMdmData();
    if (currentMdmData) {
      this.spinner.hide();
      this.currentMdmData = currentMdmData;
      this.totalMdmQuestions = Object.keys(this.currentMdmData);
    } else {
      this.calcService.getCalculatorData().subscribe(data => {
        this.spinner.hide();
        this.mdmQuestions = data;
        this.calcService.setInitialMdmState(this.mdmQuestions);
        this.initialDataState();
      });
    }
  }

  onMdmEncounterUpdate(val) {
    setTimeout(() => {
      this.encounterTimeValue = val;
    })
  }

  onTimeEncounterUpdate(val) {
    setTimeout(() => {
      this.encounterMdmValue = val;
    })
  }

  initialDataState() {
    this.currentMdmData = this.groupingMdmData(this.calcService.getInitialMdmState());
    this.totalMdmQuestions = Object.keys(this.currentMdmData);
    this.calcService.setCurrentMdmData(this.currentMdmData);
  }

  onCheckMdmCheckBoxes(dbcmData: any) {
    //breadcrumb settings
    this.setBreadCrumbData(dbcmData.P, dbcmData.D, dbcmData.R, dbcmData.ML);
    //other work
  }

  loadData(prm: string) {
    if (prm === 'mdm') {
      let timeData = this.calcService.onGetTimeData();
      localStorage.setItem("timeData", timeData);
      this.timeValueData = (timeData) ? timeData : undefined;
    }
    this.calcObj.activeTab = prm;
  }

  resetTimeEncounter() {
    this.resetSubscription = this.calcService.getAlert().subscribe((res) => {
      setTimeout(() => {
        this.encounterMdmValue = "Established";
      })
    })
  }

  calOption(val) {
    setTimeout(() => {
      this.encounterMdmValue = this.calcService.getEncounterMob();
    })
    this.calcObj.activeTab = val;
  }

  setBreadCrumbData(P = "Select", D = "Select", R = "Select", ML = "Select") {
    this.breadCrumbData.P = P;
    this.breadCrumbData.D = D;
    this.breadCrumbData.R = R;
    this.breadCrumbData.ML = ML;
  }

  resetMdmData() {
    this.initialDataState();
  }

  isMdmInpIsSelected(mdmData: any) {
    var isSelected = false;
    mdmData.forEach(data1 => {
      data1.forEach(data2 => {
        data2.options.forEach(element => {
          if (element.selected) {
            isSelected = true;
            return;
          }
        });
      });
    });
    return isSelected;
  }

  groupingMdmData(mdmData: any) {
    const obj = {};
    mdmData.forEach(data => {
      if (!obj[data.level]) {
        obj[data.level] = [];
      }
      obj[data.level].push(data);
      data.options.forEach(element => {
        element.selected = false;
      });
      if (data.level == "D") {
        obj["D"]["typeCategory"] = Object.values(
          this.groupBy(obj[data.level], "typeCategory")
        );
      }
    });
    return obj;
  }

  // Accepts the array and key
  groupBy = (array, key) => {
    // Return the end result
    return array.reduce((result, currentValue) => {
      // If an array already present for key, push it to the array. Else create an array and push the object
      //console.log("cccc", currentValue);
      (result[currentValue[key]] = result[currentValue[key]] || []).push(
        currentValue
      );
      // Return the current iteration `result` value, this will be taken as next iteration `result` value and accumulate
      return result;
    }, {}); // empty object is the initial value for result object
  };
}
