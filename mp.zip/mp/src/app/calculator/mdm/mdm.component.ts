import {
  Component,
  Input,
  ViewChildren,
  QueryList,
  ElementRef,
  Output,
  EventEmitter,
  OnDestroy,
  AfterViewInit
} from "@angular/core";
import { CalculatorService } from "../calculator.service";
import { Subscription } from 'rxjs';
import { Router } from '@angular/router';
@Component({
  selector: "app-mdm",
  templateUrl: "mdm.component.html"
})
export class MdmComponent implements OnDestroy, AfterViewInit {
  @Input() currentMdmData: any;
  @Input() totalMdmQuestions: any;
  @Input() dataState: any;
  @Output() onChangeCheckBoxes = new EventEmitter<any>();
  @Output() calOptionName = new EventEmitter<any>();
  @Output() encounterUpdate = new EventEmitter<any>();
  encounterName: any = "Established";
  mdmDataList: any;
  checkData: any = {};
  displayCptCode: any;
  code = ['P', 'D', 'R'];
  resetSubscription: Subscription;
  getEncounterSubs: Subscription;
  mdmLevel: any;
  alert: boolean = false;
  sendData: any = {};
  modalView: boolean = true;
  my_modal_title: any;

  @ViewChildren("checkboxes") checkboxes: QueryList<ElementRef>;

  constructor(private calcService: CalculatorService, private routes: Router) {
  }

  ngOnInit() {
    this.getEncounterSubs = this.calcService.getEncounterMdmName().subscribe((res) => {
      this.encounterName = res;
      this.encounterUpdate.emit(res);
      this.dataCreated(this.code);
    });
    this.resetSubscription = this.calcService.getAlert().subscribe((res) => {
      this.resetData();
      this.encounterUpdate.emit("Established");
    })
    this.encounterUpdate.emit(this.encounterName);
  }

  ngAfterViewInit() {
    if (this.dataState) {
      setTimeout(() => {
        this.resetData();
      },100);
    }
    else {
      let encouter = this.calcService.getEncounterMob();
      (encouter) ? this.encounterName = encouter : this.encounterName;
      this.encounterUpdate.emit(this.encounterName);
      this.getStateChangeData();
    }
  }

  resetData() {
    this.displayCptCode = "";
    this.code.forEach((res) => {
      this.checkData[res] = undefined;
      this.onUnCheckAllData(res);
      this.uncheckNone(res + "-none");
    })
    this.checkData['ML'] = undefined;
    this.mdmLevel = undefined;
    this.onChangeCheckBoxes.emit(this.checkData);
  }

  getStateChangeData() {
    if (this.currentMdmData) {
      this.dataCreated(this.code);
    }
  }

  ngOnDestroy() {
    this.getEncounterSubs.unsubscribe();
    this.resetSubscription.unsubscribe();
  }

  onNone(event, level = "P") {
    const elems = document.querySelectorAll("*[id^=inp-" + level + "]");
    elems.forEach(element => {
      (element as HTMLInputElement).checked = false;
    });
    this.onUnCheckAllData(level)
    this.dataCreated(this.code);
    this.checkData[level] = undefined;
    this.onChangeCheckBoxes.emit(this.checkData);
  }

  onUnCheckAllData(level) {
    if (this.checkboxes) {
      this.checkboxes.forEach((element, indx) => {
        this.currentMdmData[level].forEach(elem => {
          elem.options.forEach(el => {
            if (`inp-${level}-${el.serialNumber}` == element.nativeElement.id)
              el.selected = false;
          });
        });
      });
    }
  }

  uncheckNone(elem: any) {
    (document.querySelector("#" + elem) as HTMLInputElement).checked = false;
  }

  //key function
  selectCheckBoxes(event, level = "P") {
    this.uncheckNone(level + "-none");
    //console.log("eee", event);
    let value = event.target.className.split(" ")[1];
    //manage API call
    this.checkboxes.forEach((element, indx) => {
      let key = element.nativeElement.getAttribute("rel");
      this.currentMdmData[key].forEach(elem => {
        elem.options.forEach(el => {
          if (`inp-${key}-${el.serialNumber}` == element.nativeElement.id)
            el.selected = element.nativeElement.checked;
        });
      });
    });
    this.dataCreated(this.code);
    this.calcService.setCurrentMdmData(this.currentMdmData);
  }

  open(res) {
    this.calcService.setEncounterMob(this.encounterName);
    this.my_modal_title = res;
    if (res === 'mobile') {
      this.modalView = true;
      this.calcService.setSummaryData(this.sendData);
      this.routes.navigate(['/calculator/mobile-summary']);
    }
    else {
      this.modalView = false;
    }
  }

  calOption(val) {
    this.calOptionName.emit(val);
  }

  close(val) {
    this.modalView = val;
    if (val) {
      this.my_modal_title = '';
    }
  }

  onCloseModel(val) {
    this.modalView = val;
    if (val) {
      this.my_modal_title = '';
      this.resetData();
    }
  }

  dataCreated(level) {
    let result = []
    if (this.currentMdmData) {
      let newData = JSON.parse(JSON.stringify(this.currentMdmData));
      let dataVal = [];
      level.forEach((resp) => {
        let dataVal1 = newData[resp].filter((res) => {
          res.options = res.options.filter((ele) => {
            return ele.selected === true;
          })
          return res.options.length > 0;
        });
        dataVal.push(dataVal1);
      })
      result = [].concat.apply([], dataVal);
      let payload = {
        "patientType": this.encounterName,
        "questionDto": result,
      }
      this.calcService.getMdmCptCode(payload).subscribe((res) => {
        if (res) {
          this.sendData = res;
          this.checkData['P'] = (res.problemLevel !== null) ? res.problemLevel : undefined;
          this.checkData['D'] = (res.dataLevel !== null) ? res.dataLevel : undefined;
          this.checkData['R'] = (res.riskLevel !== null) ? res.riskLevel : undefined;
          this.checkData['ML'] = (res.cptCode !== null) ? res.mdmlevel : undefined;
          this.mdmLevel = (res.cptCode !== null) ? res.mdmlevel : undefined;
          this.displayCptCode = (res.cptCode !== null) ? res.cptCode : undefined;
          this.onChangeCheckBoxes.emit(this.checkData);
        }
      })
    }
  }
  getOptionType(inpType: string) {
    return inpType.replace(/(^\s+|\s+$)|\s+/g, "$1").toLowerCase();
  }
}
