export const staticData={
    timeActivities:[
        "Preparing to see the patient (e.g. review of tests)",
        "Obtaining and/or reviewing separately obtained history",
        "Performing a medically appropriate examination and/or evaluation",
        "Counseling and Educating the patient/family/caregiver",
        "Ordering medications, tests, or procedures",
        "Referring and communicating with other health care professionals (when not separately reported)",
        "Documenting clinical information in the electronic or other health record",
        "Independently interpreting results (not separately reported) and communicating results to the patient/family/caregiver",
        "Care coordination (not separately reported)"
    ],
    timeSlideNewRange:[
        {id:11,range:"15-29"},
        {id:12,range:"30-44"},
        {id:13,range:"45-59"},
        {id:14,range:"60-74"},
        {id:15,range:"75-89"},
        {id:16,range:"90-104"},
        {id:17,range:"105+"},
    ],
    timeSlideEstRange:[
        {id:1,range:"10-19"},
        {id:2,range:"20-29"},
        {id:3,range:"30-39"},
        {id:4,range:"40-54"},
        {id:5,range:"55-69"},
        {id:6,range:"70-84"},
        {id:7,range:"85+"}
    ],
    newSliderLength:[
        0.134686,0.143097,0.142196,0.142137,0.144297,0.141236,0.152479
    ],
    estSliderLength:[
        0.10000,0.11080,0.11080,0.16950,0.16635,0.16312,0.17932
    ]
}