import { Component, Input, Output, EventEmitter } from '@angular/core';
/* import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap'; */
import { CalculatorService } from 'src/app/calculator/calculator.service';
@Component({
  selector: 'app-alert',
  templateUrl: './alert.component.html',
  styleUrls: ['./alert.component.css']
})
export class AlertComponent {
  @Input() my_modal_title;
  @Input() data;
  @Output() closeModel = new EventEmitter<any>();
  @Output() calOptionName = new EventEmitter<any>();
  addClass: boolean = false;
  displayData: any = {};
  hideShowText: boolean = false;
  fullYear: any;
  constructor(private calcService: CalculatorService) { }

  ngOnInit() {
    let arr = [];
    if (this.data.hasOwnProperty('questionsList')) {
      this.addClass = true;
      this.data.questionsList.forEach(data => {
        if (!arr[data.level]) {
          arr[data.level] = [];
        }
        arr[data.level].push(data);
      });
      if (arr.hasOwnProperty('D')) {
        arr['D'] = arr['D'].map((res: any) => {
          (res.type === 'Category 1A' || res.type === 'Category 1B') ? res.type = 'Category 1' : res.type;
          return res;
        });
        arr['D'] =this.filterArray(arr['D']);
      }
      this.displayData = arr;
    }
    let date = new Date();
    this.fullYear = date.getFullYear();
  }

  getOptions(arr) {
    let result=[];
    if(arr.length>0){
      result = arr.map((res) => {
        return (res.type === 'Category 1') ? res.options : [];
      }).filter((res) => {
        return res.length > 0;
      });
      if(result.length>0){
        result=result.reduce((acc, curr) => {
          return acc.concat(curr);
        });
      }
      return result;
    }
  }

  filterArray(arr) {
    let option = this.getOptions(arr);
    if(option.length>1 && arr.length>0){
      let result=[];
      result =Object.values(arr.reduce((acc,cur)=>Object.assign(acc,{[cur.type]:cur}),{}));
      result = result.map((res) => {
        (res.type === 'Category 1') ? res.options = option : res.options;
        return res;
      });
      return result;
    }
    else{
      return arr;
    }

  }

  onCloseModel(val) {
    this.closeModel.emit(val);
  }

  calOptions(val) {
    this.calOptionName.emit(val);
    localStorage.removeItem('timeData');
    //this.reset();
  }

  reset() {
    localStorage.removeItem('timeData');
    this.calcService.sendAlert();
  }

  readMore(val) {
    this.hideShowText = val;
  }
}
