import { Injectable } from "@angular/core";
import { HttpClient, HttpParams } from "@angular/common/http";
import { map, tap, take, exhaustMap } from "rxjs/operators";
import { environment } from "src/environments/environment";

@Injectable({ providedIn: "root" })
export class DataService {
  constructor(private http: HttpClient) {}

  //apiUrl: string = environment.apiBaseUrl + ":" + environment.port;
  apiUrl: string = environment.baseApiUrl;

  /*  fetchCalculatorData() {
    return this.http
      .get<any>(
        "https://ng-course-recipe-book-65f10.firebaseio.com/recipes.json"
      )
      .pipe(
        map(recipes => {
          return recipes.map(recipe => {
            return {
              ...recipe,
              ingredients: recipe.ingredients ? recipe.ingredients : []
            };
          });
        }),
        tap(recipes => {
          this.recipeService.setRecipes(recipes);
        })
      );
  } */

  getCalculatorData() {
    //return 111;
    return this.http
      .get<any>("https://jsonplaceholder.typicode.com/todos")
      .pipe(
        map(data => {
          return data;
        })
      );
  }

  getCptCodes() {
    return this.http.get<any>(this.apiUrl + "/getCptCodes");
  }
}
