import { Component, OnInit } from '@angular/core';
import { CalculatorService } from 'src/app/calculator/calculator.service';
import { Subscription } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-mobile-summary',
  templateUrl: './mobile-summary.component.html',
  styleUrls: ['./mobile-summary.component.css']
})
export class MobileSummaryComponent implements OnInit {
  subscription: Subscription;
  sendData: any = {};
  my_modal_title: any;
  constructor(private calcService: CalculatorService, private routes: Router) { }

  ngOnInit() {
    if (this.calcService.getSummaryData()) {
      this.sendData = this.calcService.getSummaryData();
      this.my_modal_title = 'mobile';
    }
  }

  onCloseModel(val) {
    if (val) {
      this.calcService.setMobileState(val,undefined);
      this.routes.navigate(['/calculator']);
    }
  }

  closeSummary() {
    this.calcService.setMobileState(false,"mobile");
    this.routes.navigate(['/calculator']);
  }

  calOption(val) {
    this.calcService.setMobileState(false,undefined);
    this.calcService.setOptionData(val);
    this.routes.navigate(['/calculator']);
  }

}
