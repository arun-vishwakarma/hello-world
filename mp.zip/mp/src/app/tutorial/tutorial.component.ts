import { Component } from "@angular/core";
@Component({
  selector: "app-tutorial",
  template: `
    TTTTT

    <router-outlet></router-outlet>
  `
})
export class TutorialComponent {}
