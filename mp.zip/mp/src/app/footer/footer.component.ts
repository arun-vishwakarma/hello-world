import { Component, OnInit } from "@angular/core";
import { Router, NavigationEnd, ActivatedRoute } from "@angular/router";
import { filter } from "rxjs/operators";

@Component({
  selector: "app-footer",
  templateUrl: "./footer.component.html",
  styleUrls: ["./footer.component.css"]
})
export class FooterComponent implements OnInit {
  constructor(private router: Router, private route: ActivatedRoute) {}
  fullYear:any;
  currentUrl: any;
  ngOnInit() {
    this.router.events
      .pipe(filter(evt => evt instanceof NavigationEnd))
      .subscribe(event => {
        console.log("eee", event);
        //event["url"]
        this.currentUrl = this.route.firstChild.routeConfig.path;
      });
      let data= new Date();
      this.fullYear=data.getFullYear();
  }
}
